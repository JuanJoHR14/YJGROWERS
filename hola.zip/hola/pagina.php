<?php
session_start();
if (isset($_SESSION['nombredelusuario']))
{
    $usuarioingresado = $_SESSION['nombredelusuario'];
    echo "<h1>BIENVENIDO: $usuarioingresado  </h1>";
}
else
{
    header('location: index.php');
}
if (isset($_POST['btncerrar']))
{
    session_destroy();
    header('location: index.php');
}
?>
<link rel="stylesheet" href="dise_pag.css">

<header> 
    <div class="h">
        <img src="logo.png" alt="" width="8%">
        <h1 class="a">ASCEND</h1> 
        <img src="logo.png" alt="" width="8%">
     
    </div>
</header>


<nav>
    <div>
        <h1 class="b">SOBRE NOSOTROS</h1> 
    </div>

</nav>


<aside> 
    <div class="l">
        <div>
        <ul>
            <li>Te podria interesar:</li>
        </ul>   
        </div>
        <div>
            <a href="">Contactanos</a>
        </div><br>
        <div>
            <a href="">Servicios</a>
        </div><br>
        <div>
            <a href="">Comentarios</a>
        </div><br>
        <div>
            <img src="nue.png" alt="" widht="20%" height="50%">
        </div>
    </div>
</aside>


<section>
    <div class="si">
        <div class="no">
            <video class="vi" src="ayu.mp4" controls></video>
           
        </div>
        <div class="wno">
            <h4>SOMOS</h4>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex
            excepturi, animi reprehenderit ab qui commodi fugit cumque
            provident deserunt error illo ratione praesentium doloribus
            consequatur odio debitis exercitationem quidem quod?
            excepturi, animi reprehenderit ab qui commodi fugit cumque
            provident deserunt error illo ratione praesentium doloribus</p>
        </div>
    </div>
</section>


<article>
    <div class="c">
        <div>
            <h4>MISION</h4>
            <P class="ñ">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex
            excepturi, animi reprehenderit ab qui commodi fugit cumque
            provident deserunt error illo ratione praesentium doloribus
            consequatur odio debitis</P>

        </div>
        <div class="k">
            <img src="ho.png" alt="" widht="20%" height="20%">
        </div>
        <div>
            <h4>VISION</h4>
            <P class="n">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex
            excepturi, animi reprehenderit ab qui commodi fugit cumque
            provident deserunt error illo ratione praesentium doloribus
            consequatur odio debitis</P>

        </div>
    </div>

</article>

<footer><a href="">Politica de privacidad</a></footer>
<footer><a href="">Declaracion de cookies</a></footer>
<footer><a href="">Desarrolladores</a></footer>
<footer><a href="">Limitacion de responsabilidad</a></footer>
<body>
    <form method="POST">
        <input style="align-items: center; display: flex; justify-content: center; background-color: rgb(23, 87, 182);float: center; width: 20%; height: 10%;
    border-color: aliceblue; color: rgb(255, 255, 255);" type="submit" value="Cerrar Sesion" name="btncerrar">

    </form>
</body>