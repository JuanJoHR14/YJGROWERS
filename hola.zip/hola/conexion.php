<?php
$dbname="empresa_liber";
$dbuser="root";
$dbhost="localhost";
$dbpass="";
$dbport=3307;

$conexion=mysqli_connect($dbhost, $dbuser, $dbpass, $dbname,$dbport);


?>