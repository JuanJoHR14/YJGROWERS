<?php
session_start();

require_once("clase.php");

$usar_db = new DBControl();

if(!empty($_GET[]))
{
    switch($_GET["accion"])
    {
        case "agregar":
            if(!empty($_POST[""]))
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>COMPRAS</title>
</head>
<body>
    <div align="center"><h1>Carrito de Compras</h1></div>
    <nav>MENÚ</nav>
    <div><h2>LISTA DE PRODUCTOS A COMPRAR</h2></div>
    <table>
        <tr>
            <th>Descripcion</th>
            <th>Código</th>
            <th>Cantidad</th>
            <th>Precio x unidad</th>
            <th>Precio total</th>
            <th><a href="productos.php?accion=vacio">Borrar</a></th>
        </tr>
        <tr>
            <td colspan="2"><b>TOTAL DE PRODUCTOS</b></td>
            <td><b><?php echo $totcantdd; ?></b></td>
        </tr>
    </table>
</body>
</html>