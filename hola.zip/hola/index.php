<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <link rel="stylesheet" href="login.css">
</head>
<body>
    <form action="" method="POST">
        <table>
            
            <tr>
                <td colspan="2" style="Background:#27BEF5; padding-bottom: 10px;"><label>INICIAR SESION</label></td>
            </tr>
            
            <tr>
                <td rowspan="8"><img src="logo.png" alt="" widht="200" height="200"></td>
                <td><label>USUARIO</label></td>
            </tr>
            <tr>
                <td><input type="text" name="textusuario" placeholder="Ingresar usuario" required></td>
            </tr>
            <tr>
                <td><label>CONTRASEÑA</label></td>
            </tr>
            <tr>
                <td><input type="password" name ="textpassword" placeholder="Ingresar contraseña" required></td>
            </tr>
            <tr>
                <td><label>ROL</label></td>
            </tr>
            <tr>
                <td>
                    <select name="rol">
                        <option value="0" style="display:none;"><label>Seleccionar</label></option>
                        <option value="usuario">Usuario</option>
                        <option value="Admin">Administrador</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td><input type="submit" name="JIngresar" value="INGRESAR"></td>
            </tr>
            <tr>
                <td><a href="registrar.html">Crear una nueva cuenta</a><br><br><a href="">¿Olvidé mi contraseña?</a></td>
            </tr>

        </table>
    </form>
</body>
</html>
<?php
session_start();
if(isset($_SESSION['nombredelusuario']))
{
    header('location: pagina.php');
}
if(isset($_POST['JIngresar']))
{
    include('conexion.php');
    if(!$conexion)
    {
        die("NO HAY CONEXION" .mysqli_connect_error());
    }
    $nombre = $_POST['textusuario'];
    $pass = $_POST['textpassword'];
    $rol = $_POST['rol'];

    $query = mysqli_query($conexion, "Select * from login where usuario = '".$nombre."' and password = '".$pass."' and rol = '".$rol."'");
    $nr = mysqli_num_rows($query);
    if($nr==1)
    {
        if($rol == "usuario")
        {
            $_SESSION['nombredelusuario']=$nombre;
            header("location: pagina.php ");
        }
        else if($rol == "Admin")
        {
            $_SESSION['nombredelusuario']=$nombre;
            header("location: pagina2.php ");
        }
    }
    else if ($nr==0)
    {
      echo"<script>alert('USUARIO, CONTRASEÑA O ROL INCORRECTO');window.location='index.php' </script>";
    }
        
}
?>