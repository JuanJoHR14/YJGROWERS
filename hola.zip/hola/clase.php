<?php
    class DBControl {
        private $conexion;

        function __construct()
        {
            $this -> conn = $this ->conectarDB();
        }

        function conectarDB()
        {
            $conexion = mysqli_connect("localhost", "root", "", "empresa_liber")
            return $conexion;
        }

        function carritoquery($query)
        {
            $resultado = mysqli_query($this->conn,$query);
            while($fila=mysqli_fetch_assoc($resultado))
            {
                $obt_resul[] = $fila;
            }
            if (!empty($obt_resul))
            {
                return $obt_resul;
            }    
        }
        function nfilas($query)
        {
            $resultado = mysqli_query($this->conn,$query);
            $total_fils = mysqli_num_rows($resultado);
            return $total_fils;
        }

    }
    

?>